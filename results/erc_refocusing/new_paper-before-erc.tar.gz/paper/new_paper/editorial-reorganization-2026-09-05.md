# Réorganisation éditoriale — 5 septembre 2026

## Périmètre

Réécriture du texte principal et réorganisation des annexes, sans nouvelle
simulation, changement de données, de poids, de coût ou de résultat.
Les modifications antérieures et les fichiers de recherche restent en place.

Le texte principal suit maintenant quatre questions : réplication publique,
effet de la diversification, distinction composition/levier, puis dépendance
aux hypothèses. Le test de revenu commun est traité explicitement entre les
comparaisons de composition et la synthèse des sensibilités : son résultat
défavorable à l'équipondération reste une limite centrale, non un détail caché.

## Texte principal

- Introduction recentrée sur le contrefactuel moderne, le lien avec ACO,
  l'expérience, le résultat et ses principales limites. Suppression de
  l'inventaire chiffré des exclusions historiques.
- Section 1 raccourcie : question d'allocation et différence entre une
  réplication annuelle qualitative et une reproduction exacte d'ACO.
- Sources MF détaillées, moments complets et contrôles intermédiaires
  déplacés vers les annexes correspondantes.
- Tableau de conception centré sur ACO et les deux familles, avec des poids
  exprimés en fonction de l'exposition G. Les anciens contrôles restent en B.1.
- Nouveau tableau principal : mêmes résultats archivés aux expositions
  100 %, 175 % et 200 %. Les cinq niveaux restent dans la Figure 1 et les
  tableaux d'annexe. Aucun point de la grille n'a été recalculé.
- Résultats structurés en réplication, diversification, levier/ablations,
  revenu commun et synthèse des sensibilités. Les résultats à 200 % issus
  d'autres grilles ne sont plus mélangés aux illustrations centrales à 175 %.
- Détails des produits de financement, taxes et marges regroupés en E.
  Les omissions de fiscalité et de liquidation forcée restent explicites
  dans la méthode principale.
- Discussion sur l'adoption agrégée conservée. Conclusion raccourcie,
  sans nouvel inventaire de contrôles ni affirmation de dominance universelle.

Le fichier LaTeX principal passe d'environ 9 670 à 5 600 mots séparés par
des espaces (mesure incluant commandes et tableaux, non un comptage éditorial
normalisé). Le PDF conserve 52 pages au total : le parcours principal se
termine page 14, la bibliographie suit, et le guide des annexes est page 19.
Il s'agit surtout d'une séparation du récit et de sa documentation.

## Nouvelle carte des annexes

| Ensemble | Contenu et principales destinations |
| --- | --- |
| A — Données et reconstruction, p. 20 | Histoires de rendement A.1 ; construction/validation MF A.2 ; moments poolés A.3. |
| B — Allocation et exposition, p. 28 | Contrôles intermédiaires B.1 ; échelles diversifiées B.2 ; ACO à levier identique B.3 ; ablations B.4 ; rôles après 1970 B.5. |
| C — Histoire et disponibilité, p. 32 | Événements et pays C.1 ; fenêtres C.2 ; disponibilité progressive C.3 ; rééchantillonnage historique C.4 ; traitements alternatifs du panel C.5. |
| D — Objectifs du ménage, p. 41 | Revenu commun D.1 ; préférences D.2 ; contribution/retrait D.3, y compris ACO à levier identique. |
| E — Mise en œuvre, p. 45 | Financement E.1 ; coûts et détérioration MF E.2 ; bill réel E.3 ; marges E.4 ; fiscalité E.5. |
| F — Réplication, p. 52 | Identifiants, sources, conversions et liens vers l'historique de développement. |

Le guide contient des liens cliquables et des numéros de page calculés par
LaTeX. Les labels de référence existants ont été conservés autant que possible,
ce qui permet aux numéros de sections, figures et tableaux de suivre les déplacements.

Les comparaisons d'anciennes implémentations ne servent plus de tests
scientifiques supplémentaires dans le corps du papier. Elles sont conservées
dans `replication-development-notes.md` et l'existant `figures/aco_methods.tex`.
La convention économique distincte de couverture intégrale reste résumée en F ;
les contrôles scientifiques d'exclusion et de traitement du panel restent en C.

## Contrôles de livraison

- Pas de lancement de scripts de simulation ni d'édition des résultats JSON/CSV.
- Valeurs du nouveau tableau principal issues des résultats de référence déjà
  vérifiés dans l'expérience appariée de disponibilité historique.
- Maintien dans le récit du renversement sur le revenu commun, de la sensibilité
  de la variance aux conversions extrêmes et de la fragilité relative de
  l'équipondération dans le rééchantillonnage historique et les stress MF.
- Bibliographie reconstruite avec Biber ; passes LaTeX jusqu'à stabilisation.
- Aucune référence indéfinie, aucun avertissement LaTeX, aucun débordement signalé.
- Vérification visuelle du tableau central et du guide des annexes.
- `git diff --check` sans erreur.
