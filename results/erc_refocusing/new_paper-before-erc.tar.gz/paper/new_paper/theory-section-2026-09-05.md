# Section théorique et estimation des seuils

Ajout de la section 5, pages 13–16, dans `theory-frontier.tex` :

1. Définition de la frontière épargne équivalente–ruine sous contrainte
   d'utilité, avec distinction explicite entre frontière et courbes de levier.
2. Modèle de diffusion, équation HJB, séparation composition/exposition et
   dérivation de la condition marginale d'exclusion relative à ACO.
3. Estimation des seuils et des intervalles historiques, puis conclusion
   conditionnelle sur la possibilité de conserver une allocation actions seules.

Annonce dans l'introduction, renvois dans le plan et la conclusion, sources
Bayraktar–Young 2007 et 2008 consultées et ajoutées à la bibliographie.
La méthode empirique est documentée en annexe B.6, annoncée dans le guide.

La compétence quant-research a conduit à maintenir le calcul de seuils séparé
du moteur de simulation, vérifier les rendements contre les résultats gelés,
rééchantillonner les années par blocs avec tous les pays contemporains, et
conserver les résultats négatifs ainsi que l'incertitude.

Résultats nouveaux : moments et seuils seulement, aucun nouveau portefeuille
optimal ni nouvelle simulation de ménage. Panel complet inchangé. MF : écart
au seuil de 6,27 points par an (6,01 sur la branche d'emprunt intérieure à
30 pb), contre 1,16 pour les obligations et -2,30 pour l'or. Depuis 1970,
les trois estimations ponctuelles sont positives. Les intervalles pour les
obligations et l'or comprennent zéro dans les deux fenêtres.

Ces seuils ne prouvent pas l'optimalité d'ACO 33/67 sans levier, même lorsqu'ils
sont franchis. Ils n'estiment pas une frontière de cycle de vie et ne
démontrent pas que chaque diversifiant exige une forte rupture future pour
être exclu. La discussion d'adoption agrégée reste distincte, après la théorie.

Reproduction, tests et empreintes : `results/exclusion_thresholds/README.md`
et `estimates.json`. Le tableau généré est
`paper/new_paper/figures/exclusion_thresholds.tex`.
