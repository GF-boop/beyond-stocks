# Reviewer corrections — 5 September 2026

Scope: editorial corrections and deterministic diagnostics on the frozen
1927–2025 baseline. No new lifecycle simulation, strategy optimization,
sample exclusion, or after-tax simulation was performed.

## Changes and evidence

1. **Leverage and real bills.** New Table 6 decomposes 175% minus 100%
   exposure at fixed composition for ACO, proportional, and equal-weight
   portfolios, across pooled ex-post real-bill quintiles (1,561 rows).
   Every row's four accounting components reconcile to the observed return
   increment to 1e-12. All archived ladder volatilities are independently
   reproduced before calculating the diagnostic. Proportional/equal-weight
   mean increments are 3.82/3.60 percentage points; 1940–1949 and 1970–1979
   contribute 30.8%/38.2% of those means, on 19.5% of observations. Outside
   those decades the increments remain 3.29/2.76 points. This is not a
   causal inflation estimate or an attribution of ruin/utility gains.
2. **Changing numeraire.** Bootstrap text explicitly covers both block
   restarts and forced within-block continuation. It distinguishes joining
   resident-real return histories from creating an FX transaction at a join.
3. **MF realized volatility.** Appendix B.4 reconciles monthly excess-return
   annualized SD (10.53%) with annual total-return dispersion. Net annual
   panel SD is 14.25% using N−1, or 14.18% using N, the existing descriptive
   table convention. The three-times scalar cap binds in 26.4% of months;
   it is not a realized-volatility ceiling. The lagged 36-month estimator
   requires at least 24 observations. Construction inspected in the frozen
   monthly generator in the neighboring CTO_vs_PEA project; not modified.
4. **Taxation.** Added a scoped paragraph on omitted personal taxes and
   vehicle/account dependence. Sources: IRS Topic 409, GLD's 2022 grantor
   trust statement, and DBMF's 30 April 2026 SEC summary prospectus. The
   collectibles rate is described as a maximum, not a flat tax. Cost
   stresses are explicitly not an after-tax analysis.
5. **Benchmark overlap.** KMLMSIM/KMLM are identified as extended/live
   histories of the same strategy, not independent confirmations.
6. **Baltas.** The 2015 chapter author is standardized to Nick Baltas,
   matching the publisher record, DOI 10.1016/B978-1-78548-008-9.50003-4;
   pages 65–95 added. Biber rebuilt the author-year references.
7. **Panel count.** Policy-sensitivity note and generator corrected from
   1,557 to 1,561; the baseline reader verifies 1,561 observations.
8. **Correlation memo.** Removed stale 0.51. The generator now calculates
   the commercial-index range (0.55–0.59) from the same monthly series.
   KMLMSIM and live ETF correlations remain separately window-labeled.
9. **Mean/SD.** Replaced Sharpe-zero labels in annual diagnostics and
   variants, including generators; stated N versus N−1 conventions.
10. **Naming.** Standardized Domestic balanced and 1st percentile in the
    active main and full-panel moment tables and relevant generator.
11. **Pooled versus U.S. moments.** Added reciprocal cross-references,
    explicitly distinguishing 1,561 country-years from 99 U.S. years.

Additional consistency correction: the annual appendix generator retained
a stale 0.57% turnover deduction. It now imports the same measured cost as
the baseline (0.6146048%). This changes the MF mean from 8.10% to 8.05%,
and updates the associated cumulative-wealth/scatter exhibits. Lifecycle
results and the panel itself are unchanged. The variants note also now
acknowledges cash-leg normalization, not just monthly versus annual costs.

## Reproduction and checks

From the Cederburg_lifecycle root, with a Python environment containing
NumPy and pandas (used here: /mnt/Data/caillasse/caillasse/.venv/bin/python3):

```sh
python3 build/review_bill_volatility.py
python3 paper/build_appendix_data.py --output-dir paper/new_paper/figures --fixed-notional
python3 paper/build_mf_benchmark_data.py
```

The last command requires locally held licensed index inputs; it does not
download them. Diagnostics and input SHA-256 hashes are archived in
`results/method_review/bill_volatility/audit.json`.

From paper/new_paper, compilation used pdflatex, biber, and repeated
pdflatex passes. Final PDF: 48 pages; no LaTeX warnings, undefined
references, or overfull/underfull boxes. Extracted text checked for table
contents, cross-references, and removal of the reported stale strings.
`git diff --check` passes. Earlier annotated PDFs and backup sources are
intentionally untouched.
