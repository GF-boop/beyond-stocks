# Archived implementation comparisons

These exhibits document superseded implementations and source-screen variants.
They are retained here rather than presented as additional main-text evidence.
No archived simulation file has been changed. The economically distinct
full-terminal-value hedge remains summarized in the replication appendix.

## Former implementation table

```latex
Table~\ref{tab:method-sensitivity} records the checks most relevant to the construction.
A return-dependent screen lowers measured volatility substantially.
We report it as a construction diagnostic alongside the unscreened baseline. Reverting to the former bootstrap end treatment or to the idealized hedge
changes levels modestly but does not reverse the ranking. A leave-one-source-country-out
exercise removes the country from resident observations and from the global equity and bond
baskets. Across the 16 omissions, benchmark ruin ranges from 7.10\% to 8.66\%, while the two
200\% sensitivity endpoints remain below it (ranges 0.90--2.88\% and 1.36--3.16\%). This
supports robustness of the ordering, while also showing that its absolute risk depends on the
historical sample.

\begin{table}[t]
\centering
\caption{Implementation checks}\label{tab:method-sensitivity}
\small
\setlength{\tabcolsep}{3pt}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lrrr}
\toprule
Specification & ACO ruin & Proportional 200\% ruin & Equal-weight 200\% ruin \\
\midrule
Corrected baseline & 6.98\% & 1.80\% & 2.27\% \\
Legacy bootstrap end treatment & 7.38\% & 1.84\% & 2.26\% \\
Ideal full-value hedge & 6.98\% & 1.82\% & 2.27\% \\
Frozen legacy return screen (diagnostic only) & 7.38\% & 1.57\% & 2.02\% \\
Leave-one-source-country-out range & 7.10--8.66\% & 0.90--2.88\% & 1.36--3.16\% \\
\bottomrule
\end{tabular}
}
\begin{minipage}{0.94\textwidth}\footnotesize
\textit{Note:} First four rows use 10,000 paired simulations; the leave-one-out range
uses 5,000 per omission. The 200\% columns assess robustness of the portfolio ordering;
their volatility exceeds that of ACO in the baseline.
\end{minipage}
\end{table}


```

## Matched-exposure construction checks

The existing [`figures/aco_methods.tex`](figures/aco_methods.tex) preserves
all rows, including block restart, return screen, war screen and source-country
ranges. Its generator and numerical archives remain unchanged.

The current paper retains source-event, historical-window and alternative-panel
sensitivities in Appendix C. These tests must not be conflated with changes
made during development of the baseline implementation.
