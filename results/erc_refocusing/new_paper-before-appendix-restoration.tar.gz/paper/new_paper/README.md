# Public-data multi-asset retirement comparison

Current manuscript: [main-styled.pdf](main-styled.pdf).

The September 6 revision recenters the original ACO extension and compares
three families: ACO 33/67, fixed proportional weights, and retrospective
equal-risk-contribution (ERC) weights. Each uses the same 100–200% exposure
grid. The equal-capital family and the separate frontier/derivative theory
are no longer included in this PDF; all earlier files/results remain archived.

The main outcomes are utility-equivalent saving and own-capital retirement
ruin. A common planned ACO-income test remains prominent and gives an
unfavorable full-panel result for ERC. The manuscript does not claim that ERC
maximizes household utility, that 175% is an optimum, or that the calibration
is out of sample.

## Reading map

1. Introduction: opportunity set and financing question.
2. Data and experimental design: household, returns, covariance and exposure.
3. Household-value framework: composition, exposure and utility-equivalent saving.
4. Results: replication, allocation ladders and sleeve ablations.
5. Conditions: common income, historical regimes and implementation costs.
6. Economic scope and conclusion.

The short framework in `utility-framework.tex` uses the same withdrawal,
consumption-floor and bequest conventions as the empirical engine. It is not
the earlier standalone frontier theory or a new asset-pricing method.
Its deterministic checks are documented in
[the integration note](utility-framework-integration-2026-09-06.md).

Appendices A–F are assembled by [appendices-refocused.tex](appendices-refocused.tex).
The linked guide explains their functions. Old appendix and theory files are
preserved but not included.

## Evidence and rebuild

Numerical protocol/results: [ERC experiment](../../results/erc_refocusing/README.md).
Authoritative run: `../../results/erc_refocusing/n10000_final/`.
New baseline estimates reproduce the original ACO/proportional ladder results;
do not copy old equal-capital sensitivities onto ERC.
The earlier historical-availability result is explicitly proportional-only.

From the project root:

```sh
python3 build/render_erc_refocusing.py
```

Then from this directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error main-styled.tex
biber main-styled
pdflatex -interaction=nonstopmode -halt-on-error main-styled.tex
pdflatex -interaction=nonstopmode -halt-on-error main-styled.tex
```

The renderer verifies frozen source hashes; compilation itself runs no simulation.
It generates `figures/erc/` without changing the old exhibit files.
Do not run old exhibit scripts as an implicit update to this manuscript.

See [editorial change record](refocusing-erc-2026-09-06.md) for preserved
limitations, source checks and the snapshot location.
